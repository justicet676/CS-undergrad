/*
	Name: Justice Turner
	Date: 17 August 2025
	Description: A program for Corner Grocer that reads a file, and can tell you the frequency of certain items within said file. 
	For the purpose of seeing how much stock of what item sold in a given day
*/

using namespace std;
#include <iostream> //to allow input and output
#include <fstream> //for file operations i.e. opening/closing
#include <string>
#include <sstream>
#include <map>
#include <algorithm>

void printMenu() {
	cout << "Please select from one of the following menu options, using the number keys 1-4" << endl;
	cout << "1: Frequency of purchase by item" << endl;
	cout << "2: A list of all items and purchase frequency" << endl;
	cout << "3: A list of all items and purchase frequency by histogram" << endl;
	cout << "4: Exit Program" << endl;
}

class DataExtractor {
private:
	string outputFile;
	map<int, int> frequencies;

	void extractIntegers(const string& line) {
		string currentNumber;
		for (char c : line) {
			if (isdigit(c)) {
				currentNumber += c;
			}
			else {
				if (!currentNumber.empty()) {
					frequencies[stoi(currentNumber)]++;
					currentNumber.clear();
				}
			}
		}
		// Handle the last number in the line if it's not followed by a non-digit
		if (!currentNumber.empty()) {
			frequencies[stoi(currentNumber)]++;
		}
	}

public:
	// Constructor to initialize the filename
	DataExtractor(const string& file) : outputFile(file) {}

	// Public method to find the integer next to a given string
	int freq(const string& targetString) {
		ifstream inputFile(outputFile);
		if (!inputFile.is_open()) {
			cerr << "file not found" << outputFile << endl;
			return -1; 
		}

		string line;
		while (getline(inputFile, line)) {
			istringstream iss(line);
			string currentString;
			int currentInt;

			// Attempt to read a string and then an integer from the line
			if (iss >> currentString && iss >> currentInt) {
				if (currentString == targetString) {
					inputFile.close();
					return currentInt;
				}
			}
		}

		return -1; // Target string not found
	}
	//takes integer from file and saves for histogram
	void processFile(const string& filename) {
		ifstream inputFile(filename);
		if (!inputFile.is_open()) {
			cerr << "Error: Could not open file " << filename << endl;
			return;
		}

		string line;
		while (std::getline(inputFile, line)) {
			extractIntegers(line);
		}
		inputFile.close();
	}
	//creates histogram
	void displayHistogram() const{
		for (const auto& pair : frequencies) {
			cout << pair.first << ": ";
			for (int i = 0; i < pair.second; ++i) {
				cout << "*"; // Represent frequency with asterisks
			}
			cout << endl;
		}
	}


};


void main() {
	ofstream outputFile("frequency.dat");
	ifstream inputFile("CS210_Project_Three_Input_File.txt");
	
	int menuOption = 0;
	int freq;
	string item;


	//convert text in inputFile to outputFile
	map<string, int> itemFreq;
	while (inputFile >> item) {
		transform(item.begin(), item.end(), item.begin(),
			[](unsigned char c) { return std::tolower(c); });

		itemFreq[item]++; // Increment frequency
	}

	inputFile.close();

	// copy to output file
	for (const auto& pair : itemFreq) {
		outputFile << pair.first << ": " << pair.second << std::endl;
	}
	inputFile.close();
	outputFile.close();
	ifstream inputFile("frequency.dat");

	DataExtractor extractor("frequency.dat");

	//dowhile loop until the menuoption to exit is selected
	do {
		//trycatch to validate user input as a integer
		try {
				printMenu();
				cin >> menuOption;
				switch (menuOption) {
					case 1:
						//option 1: search file for specific purchase frequency
						cout << "Please enter product you'd like to know the purchase frequency of: ";
						cin >> item;
						cout << endl;
						freq = extractor.freq(item);
						cout << item << " " << freq << endl;
						return;
					case 2:
						//option 2: print itmes sold and frequency sold
						while (getline(inputFile , item)) {
							cout << item <<endl;
						}
					case 3:
						//option 3: display product with histogram
						extractor.processFile("frequency.dat");
						extractor.displayHistogram();
					default:
						//if integer is input that is not 1-4
						return;
				}
			
		}
		catch (const ios_base::failure& e) {
			cout << "Please input valid option" << endl;
			cin.clear();
			menuOption=0;
		}
	} while (menuOption != 4);
	if (menuOption == 4) {
		//exit program is menu option is 4
		inputFile.close();
		exit;
	}

}